# jquery.mb.vimeoPlayer

__An open source jQuery component to easily build your custom Vimeo® player or to use a Vimeo® video as background for your page.__

![mb.vimeo_player](https://pupunzi.com/mb.components/mb.vimeo_player/vimeoPlayer.jpg)

## [go to the demo](https://pupunzi.com/mb.components/mb.vimeo_player/demo/index.html)
## [go to the doc](https://github.com/pupunzi/jQuery.mb.vimeo_player/wiki/Documentation)
## [go to the blog](https://pupunzi.open-lab.com/mb-jquery-components/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web

## Available also for **Youtube**: 
https://github.com/pupunzi/jquery.mb.YTPlayer
