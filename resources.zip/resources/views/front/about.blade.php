<section id="features" class="big-reserve container about-section animated" data-animation="fadeIn" data-animation-delay="200">

    <!-- Features Background -->
    <div class="features-background parallax1 soft-bg-1" style="background-position: 50% 50%;"></div>

    <!-- Features Inner -->
    <div class="inner features">
        <!-- Header -->
        <h1  class="white header uppercase about-header">
            <span id="contents">About Us</span>
        </h1><br>
        <!-- Header Strip(s) -->
        {{-- <div class="header-strips-one t-right" ></div> --}}
        <!-- Header Description -->
        <h2 class="description white about-text">
            Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in piece of classical. There are many variations of passages of Lorem Ipsum available.<br><br>
            Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in piece of classical. There are many variations of passages of Lorem Ipsum available.
        </h2>
        
    </div>
    <!-- End Features Inner -->
</section>