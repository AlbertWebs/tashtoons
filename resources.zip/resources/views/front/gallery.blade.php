<section id="portfolio" class="container soft-bg-1">
		
    <!-- Portfolio Inner -->
    <div class="inner">
        <!-- Header -->
        <h1 class="header about-header white uppercase dark oswald">
            <span id="contents">Gallery</span>
        </h1>
        <!-- Header Strip(s) -->
        <div class="header-strips-one"></div>
        <!-- Header Description -->
        
    </div><!-- End Portfolio Inner -->
    <div class="portfolio t-center fullwidth relative">

        

        <!-- Portfolio Items -->
        <div class="portfolio-items t-center isotope" style="position: relative; overflow: hidden; height: 744px;">

            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->


            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->



            <!-- Item -->
            <div class="item five branding isotope-item" style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
                <!-- Item Link -->
                <a href="{{asset('theme/images/project/02.jpg')}}" data-rel="prettyPhoto[portfolio]" class="work-image">
                    <!-- Item Image -->
                    <img src="{{asset('theme/images/portfolio/001.jpg')}}" alt="">
                    <!-- Item Details -->
                    <div class="item-details">
                        <!-- Item Header -->
                        <h1 class="oswald uppercase white">
                            {{-- Red &amp; Dark --}}
                        </h1>
                    
                    </div>
                    <!-- End Item Details -->
                </a>
                <!-- End Item Link -->
            </div>
            <!-- End Item -->


            

            
            
        </div><!-- End Portfolio Items -->
    </div><!-- End Portfolio -->
</section>