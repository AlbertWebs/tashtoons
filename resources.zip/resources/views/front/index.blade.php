@extends('front.master')
@section('content')
	
    @include('front.slider')
   
    @include('front.about')
	
    @include('front.whatWeDo')

	@include('front.services')

	@include('front.showreel')

    @include('front.gallery')

    @include('front.clients')

	@include('front.awards')

	@include('front.contact')

@endsection