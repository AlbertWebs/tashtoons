
	<!-- What We Do Section -->
	<section id="what-we-do" class="container soft-bg-1 animated" data-animation="fadeIn" data-animation-delay="200">
		<!-- What We Do Inner -->
		<div class="inner">
			<!-- Header -->
			<h1 class="header about-header white uppercase dark oswald">
				what we do
			</h1><br><br>
			<!-- Header Strip(s) -->
			{{-- <div class="header-strips-one"></div> --}}
			<!-- Header Description -->
			<h2 class="description white about-text">
				Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in piece of classical. There are many variations of passages of Lorem Ipsum available.
			</h2>
		</div><!-- End What We Do Inner -->
	</section><!-- End What We Do Section -->